
/**
 *
 * @author Murilo Fekete
 */
public class prjExemplo5 {
    public static void main(String arg[]) {
        int cont = 1;
        
        System.out.println("\tTABUADA DO 7\n");
        do {

            System.out.println("7 * " + cont + " = " + cont * 7 );
            cont++;
        }
        while(cont<=10);
    }
}
