import java.util.Scanner;
import fatec.poo.model.Retangulo;
/**
 *
 * @author Murilo Fekete
 */
public class Aplic {
    public static void main(String[] args) {
        
    Scanner entrada = new Scanner(System.in);
    Retangulo objRet = new Retangulo();
    double medAlt, medBase;
    
    System.out.println("Digite a medida da Altura: ");   
    medAlt = entrada.nextDouble();
    System.out.println("Digite a medida da Base: ");
    medBase = entrada.nextDouble();
    
    objRet.setAltura(medAlt);
    objRet.setBase(medBase);
        
    System.out.println("Valor da altura: " + objRet.getAltura());
    System.out.println("Valor da base: " + objRet.getBase());
    System.out.println("Medida da Área: " + objRet.calcArea());
    System.out.println("Medida do Perimetro: " + objRet.calcPerimetro());
    System.out.println("Medida da Hipotenusa: " + objRet.calcDiagonal());
   
    
    }
    
}
