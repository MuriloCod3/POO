package fatec.poo.model;
/*
 * @author Murilo Fekete
 */
public class Retangulo {
    private double altura;
    private double base;
    
   public void setAltura(double a){
       altura = a;
   }
   
   public void setBase(double b){
       base = b;
   }
   
   public double getAltura() {
       return altura; 
   }
   
   public double getBase() {
       return base;
   }
   
   public double calcArea(){      
       return (base * altura);
   }
   
   public double calcPerimetro(){
       return ((base*2) + (altura*2));
   }
   
   public double calcDiagonal() {
       //double altPow = Math.pow(altura,2);
       //double basePow = Math.pow(base, 2);
       //return ( Math.sqrt(altPow + basePow) );
       return ( Math.sqrt(Math.pow(altura, 2) + Math.pow(base, 2)) );
   }
}
