
/**
 *
 * @author Murilo Fekete
 */
public class Exemplo3 {
    public static void main(String arg[]){
        int cont; 
        
        System.out.println("            TABUADA DO 7\n");
        for (cont=1; cont <= 10; cont++) {
            System.out.println("7 * " + cont + " = " + cont * 7 );
        }
         
    }
}
