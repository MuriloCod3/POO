/**
 *
 * @author Murilo Fekete
 */
public class Exemplo4 {
    public static void main (String arg[]) {
        int cont = 1;
        
        System.out.println("\t TABUADA DO 7\n");
        while (cont <= 10) {
            System.out.println("7 * " + cont + " = " + cont * 7 );
            cont ++;
        }
    }
}
