package fatec.poo.model;

/**
 *
 * @author Murilo
 */
public class Cliente extends Pessoa {
    String cpf;
    double peso; 
    double altura; 
    
    public Cliente(String id, String name, String tel) {
        super(name, tel);
        
        cpf = id;
    }
    
    public String getCpf() {
        return cpf;
    }
    
    public void setPeso(double kg) {
        peso = kg;
    }
    
    public double getPeso(){
        return peso;
    }
    
    public void setAltura(double alt){
        altura = alt;
    }
    
    public double getAltura() {
        return altura;
    } 

}
