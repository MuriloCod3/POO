package fatec.poo.model;

/**
 *
 * @author Murilo
 */
public class Pessoa {
    private String nome;
    private String telefone;

    public Pessoa(String name, String tel) {
        nome = name;
        telefone = tel;
    }

    public String getNome() {
        return nome;
    }

    public String getTelefone() {
        return telefone;
    }
}
