package fatec.poo.model;

/**
 *
 * @author Murilo
 */
public class Instrutor extends Pessoa {
    private int identificador;
    private String atuacao;
    
    public Instrutor( int id, String name, String tel) {
        super(name, tel);
        
        identificador = id;
    }
    
    public int getId(){
        return identificador;
    }
    
    public void setAtuacao(String area) {
        atuacao = area;
    }
    
    public String getAtuacao() {
        return atuacao;
    }
    
    
    
}
