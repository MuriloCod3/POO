import fatec.poo.model.Cliente;
import fatec.poo.model.Instrutor;
import java.util.Scanner;

/**
 *
 * @author Murilo
 */
public class Aplic {
    public static void main (String args[]) {
        double kg;
        double alt;
        String area;
        
        Scanner entrada = new Scanner(System.in);
        Cliente objClient = new Cliente("1010", "Murilo Silva", "15988402746");
        Instrutor objInstrutor = new Instrutor (4918, "Gustavo Lima", "15988402745");
    
        System.out.println("Qual a altura do cliente? ");
        alt = entrada.nextDouble();
        System.out.println("Qual o Peso do cliente? ");
        kg = entrada.nextDouble();        
        objClient.setAltura(alt);
        objClient.setPeso(kg);
    
        System.out.println("\n===================================");
        System.out.println("\nCPF do Cliente: " + objClient.getCpf());
        System.out.println("Nome do Cliente: " + objClient.getNome());
        System.out.println("Telefone do Cliente: " + objClient.getTelefone());
        System.out.println("Altura do Cliente: " + objClient.getAltura());
        System.out.println("Peso do Cliente: " + objClient.getPeso());
        System.out.println("\n===================================");
        
        System.out.println("Qual é a área de atuação do Instrutor? ");
        area = entrada.next();
        objInstrutor.setAtuacao(area);
        
        System.out.println("\n===================================");
   
        System.out.println("ID do Instrutor: " + objInstrutor.getId());
        System.out.println("Área de atuação: " + objInstrutor.getAtuacao());
        

    }
}
