
/**
 *
 * @author 0030482321048
 */
public class Aplic {
    public static void main (String args[]) {
      
        
        
       
    }
}
