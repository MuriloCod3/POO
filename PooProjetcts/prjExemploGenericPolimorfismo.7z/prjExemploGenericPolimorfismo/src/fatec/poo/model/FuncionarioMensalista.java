package fatec.poo.model;

/**
 *
 * @author 0030482321048
 */
public class FuncionarioMensalista {
    
}
